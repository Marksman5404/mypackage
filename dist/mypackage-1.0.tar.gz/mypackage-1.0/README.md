# mypackage
This library contains  functions that can be used to generate documentation.

# how to install this library
